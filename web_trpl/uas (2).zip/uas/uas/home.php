<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Haloo Selamat Datang</h1>
</div>

<p>
    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Fuga, autem quaerat maiores blanditiis, 
    sapiente iusto quae aliquam molestiae reprehenderit dolores laboriosam culpa ducimus sequi. 
    Eveniet alias, quasi suscipit in maxime possimus neque enim dolorem dolor et illo iste voluptatibus 
    eaque tenetur mollitia quo dicta ut odio aliquid a accusamus. Expedita vel officiis perspiciatis eligendi 
    suscipit aspernatur at rem doloremque beatae omnis ut tempore amet dolorum repellat ducimus obcaecati, 
    eos necessitatibus quasi possimus itaque fuga consequatur ad animi? Facere non odio molestias veritatis, 
    consequatur eius quisquam porro expedita doloremque voluptate illum atque labore veniam accusantium esse 
    aliquam odit nemo, blanditiis cum!
</p>
<p>
    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Culpa debitis illum asperiores
    sunt facilis soluta ipsam maxime, nesciunt laboriosam voluptatibus fugiat facere perferendis 
    neque sint amet suscipit? Repellendus nostrum ea quas numquam tempore debitis, enim neque cum 
    voluptas maiores labore praesentium earum excepturi aut laboriosam quidem fugiat sit voluptatum! Dicta.
</p>

<p>
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Corporis cupiditate molestiae labore. 
    Totam temporibus optio asperiores eum et enim itaque quos, ad ea quis debitis, consequatur minus, saepe maiores cumque eveniet non repellat aut id ullam ut explicabo? 
    Quos, officia accusamus? Iure dolores similique doloremque natus, provident rerum odio corrupti. Repellendus obcaecati necessitatibus reprehenderit iste officiis officia ex, 
    debitis tempore expedita nemo blanditiis quos consequatur doloremque voluptatum at! Enim fugit doloribus libero temporibus quod iste suscipit ut. Quia recusandae sed nesciunt 
    odit quidem modi esse non sequi aliquid voluptate nulla soluta exercitationem voluptatem porro ratione, reprehenderit aperiam dolores! Quae, omnis.
</p>